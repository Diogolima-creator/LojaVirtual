package AtividadeTeste;


import Atividade.Classes.Aluno;
import Atividade.Classes.Disciplina;
import Atividade.Classes.Professor;


public class TESTE{
    public static void main(String[] args) {
            Aluno a1 = new Aluno ("Diogo","2020.1905.045-2",8,9);
            Aluno a2 = new Aluno ("Joao","2020.1905.045-3",9,10);
            Aluno a3 = new Aluno ("Ana","2020.1905.045-4",5,6);
            Aluno a4 = new Aluno ("Jussara","2020.1905.045-5",10,9);
            Aluno a5 = new Aluno ("Thomas","2020.1905.045-6",6,6);
            Professor p1 = new Professor("Julio","123");
            Aluno[] alunos = new Aluno[5];
            Professor[] professors = new Professor[1];
            double[][] notas = {{8,9},{9,10},{5,6},{10,10},{6,6}};
            alunos[0] = a1;
            alunos[1] = a2;
            alunos[2] = a3;
            alunos[3] = a4;
            alunos[4] = a5;
            professors[0] = p1;
            Disciplina x1 = new Disciplina(alunos,professors,notas);
            a1.imprimir();
            a2.imprimir();
            a3.imprimir();
            a4.imprimir();
            a5.imprimir();
            p1.imprimir();
            x1.imprimi();
            x1.imprimimediap1p2();
            x1.imprimimaiornota();

    }


}

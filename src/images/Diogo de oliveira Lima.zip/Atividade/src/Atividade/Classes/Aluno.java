package Atividade.Classes;

public class Aluno extends Pessoa{
    private String RGA;
    private int P1;
    private int P2;

    @Override
    public String toString() {
        return this.getNome();
    }

    public int getP1() {
        return P1;
    }

    public void setP1(int p1) {
        P1 = p1;

    }

    public int getP2() {
        return P2;
    }

    public void setP2(int p2) {
        P2 = p2;

    }

    public String getRGA() {
        return RGA;
    }

    public void setRGA(String RGA) {
        this.RGA = RGA;
    }

    public Aluno(String nome,String RGA,int P1,int P2) {
        super(nome);
        this.RGA = RGA;
        this.P1 = P1;
        this.P2 = P2;
    }

    @Override
    public void imprimir() {
        System.out.println( "Nome do aluno(a) :" + this.getNome() + ", Rga do aluno(a) :" + RGA);
    }


}

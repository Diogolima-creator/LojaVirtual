package Atividade.Classes;


import jdk.swing.interop.SwingInterOpUtils;

public class Disciplina {

    Aluno[] aluno1 = new Aluno[5];
    Professor[] professor1 = new Professor[1];
    double[][] notas = new double[5][2];
    double media1=0,media2=0,aux=0;
    double maior1,maior2;
    int pos1,pos2;
    public Disciplina(Aluno[] aluno1,Professor[] professor1,double[][] notas) {
        this.aluno1 = aluno1;
        this.professor1 = professor1;
        this.notas = notas;
    }


    public void imprimi(){
        for(int i=0;i<5;i++) {
            System.out.println("Aluno [" + (i + 1) + "] :" + aluno1[i]);
        }
        System.out.println("Professor [1] :" + professor1[0]);
    }

    public void imprimimediap1p2(){
            for(int i=0;i<2;i++){
                for(int j=0;j<5;j++){
                    aux = notas[j][i];
                    if(i<=0){
                        media1 = media1 + aux;
                    }else{
                        media2 = media2 + aux;
                    }
                }
            }
        System.out.println("MediaP1 = " + media1/5);
        System.out.println("MediaP2 = " + media2/5);
    }

    public void imprimimaiornota() {
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 5; j++) {
                aux = notas[j][i];
                if (i <= 0) {
                    if (maior1 < aux) {
                        maior1 = aux;
                        pos1 = j;
                    }
                } else {
                    if (maior2 < aux) {
                        maior2 = aux;
                        pos2 = j;
                    }
                }
            }
        }
        System.out.println("O aluno(a) "+(aluno1[pos1]) +" foi o(a) que tirou a maior nota na p1, sendo essa "+maior1
        + ".\nO aluno(a) "+(aluno1[pos2])+" foi o(a) que tirou a maior nota na p2, sendo essa "+maior2+".");
    }
}

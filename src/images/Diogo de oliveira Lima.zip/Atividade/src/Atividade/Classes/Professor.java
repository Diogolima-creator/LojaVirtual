package Atividade.Classes;

public class Professor extends Pessoa {
    private String Matricula;

    public Professor(String nome,String Matricula) {
        super(nome);
        this.Matricula = Matricula;
    }

    @Override
    public String toString() {
        return getNome() +
                ", Matricula = " + Matricula;
    }

    public String getMatricula() {
        return Matricula;
    }

    public void setMatricula(String matricula) {
        Matricula = matricula;
    }

    @Override
    public void imprimir() {
        System.out.println( "Nome do professor :" + this.getNome() + ", Matricula :" + Matricula);
    }


}
